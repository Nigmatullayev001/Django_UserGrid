from datetime import date
from django.db import models


class Job(models.Model):
    job_name = models.CharField(max_length=25)

    def __str__(self):
        return self.job_name


class Person(models.Model):
    banner = models.ImageField(upload_to='photos/$Y/$m/$d/banner')
    photo = models.ImageField(upload_to='photos/$Y/$m/$d/avatar')
    full_name = models.CharField(max_length=40)
    job = models.ForeignKey(Job, on_delete=models.CASCADE)
    address = models.CharField(max_length=100)

    def __str__(self):
        return self.full_name
