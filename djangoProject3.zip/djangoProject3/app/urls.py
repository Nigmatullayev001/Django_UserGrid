from django.conf.urls.static import static
from django.contrib import admin
from django.urls import path
from app.views import IndexView, GridUser
from root import settings

urlpatterns = [
    path("", IndexView.as_view(), name="home"),
    path("user_grid/", GridUser.as_view(), name="user_grid"),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
