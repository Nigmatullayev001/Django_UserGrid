from django.contrib import admin
from .models import Person, Job

admin.site.register(Person)
admin.site.register(Job)
