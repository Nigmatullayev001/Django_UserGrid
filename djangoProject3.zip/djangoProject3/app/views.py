from django.shortcuts import render
from django.views.generic import TemplateView, ListView
from app.models import Person


class IndexView(TemplateView):
    template_name = 'home.html'



class GridUser(ListView):
    template_name = 'User_grid.html'
    model = Person
    context_object_name = 'users'
